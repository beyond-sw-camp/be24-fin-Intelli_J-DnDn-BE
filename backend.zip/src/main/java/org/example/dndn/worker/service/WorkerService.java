package org.example.dndn.worker.service;

import lombok.RequiredArgsConstructor;
import org.example.dndn.common.exception.BaseException;
import org.example.dndn.worker.config.ManagementAttendanceProperties;
import org.example.dndn.worker.fixture.WorkerScenarioFixtureLoader;
import org.example.dndn.worker.fixture.WorkerScenarioFixtureRow;
import org.example.dndn.worker.model.dto.WorkerDto;
import org.example.dndn.worker.model.entity.*;
import org.example.dndn.worker.model.enums.AttendanceStatus;
import org.example.dndn.worker.model.enums.EmploymentKind;
import org.example.dndn.worker.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;

import static java.util.Objects.requireNonNullElse;
import static org.example.dndn.common.model.BaseResponseStatus.FAIL;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class WorkerService {
    private final WorkerRepository workerRepository;
    private final AttendanceRecordRepository attendanceRepository;
    private final WorkerDocumentRepository documentRepository;
    private final WorkerSanctionRepository sanctionRepository;
    private final SafetyAccidentRepository accidentRepository;
    private final WorkerScenarioFixtureLoader workerScenarioFixtureLoader;
    private final ManagementAttendanceProperties attendanceProps;
    private final FatigueCalculationService fatigueCalculationService;

    // MANAGEMENT_001 인력 데이터 불러오기.
    @Transactional
    public WorkerDto.SyncRes syncWorkforce(String siteCode, LocalDate rosterDate) {
        if (siteCode == null || siteCode.isBlank()) {
            throw new BaseException(FAIL);
            // throw new BaseException("SYNC_SITE_REQUIRED", "siteCode 가 필요합니다.");
        }
        if (rosterDate == null) {
            throw new BaseException(FAIL);
            // throw new BaseException("SYNC_DATE_REQUIRED", "date 가 필요합니다.");
        }
        List<WorkerScenarioFixtureRow> payload = workerScenarioFixtureLoader.loadWorkersFiltered(siteCode);
        int created = 0, updated = 0;
        SyncDetailAccumulator detail = new SyncDetailAccumulator();

        for (WorkerScenarioFixtureRow item : payload) {
            Worker worker;
            Optional<Worker> existing = workerRepository.findByExternalCode(item.getExternalCode());
            if (existing.isPresent()) {
                worker = existing.get();
                worker.updateFromSync(item.toWorkerEntity());
                updated++;
            } else {
                worker = workerRepository.save(item.toWorkerEntity());
                created++;
            }
            workerRepository.flush();

            mergeScenarioDetailsFromFixture(worker, item, detail);
            normalizeRosterDayPending(worker, rosterDate, detail);
            fatigueCalculationService.recalculateAndPersist(worker.getIdx(), rosterDate);
        }

        return WorkerDto.SyncRes.builder()
                .created(created)
                .updated(updated)
                .total(payload.size())
                .documentsSynced(detail.documents)
                .sanctionsSynced(detail.sanctions)
                .accidentsSynced(detail.accidents)
                .attendanceRecordsSynced(detail.attendanceRecords)
                .build();
    }

    // sync 시 해당 근무일 행을 06:00 출근(PRESENT)으로 고정 생성.
    // `employment_kind` 는 동기화 직전 해당 일 행이 있으면 유지하고, 없으면 {@link Worker#getEmploymentKind()} 마스터 값.
    private void normalizeRosterDayPending(Worker worker, LocalDate rosterDate, SyncDetailAccumulator acc) {
        Long wid = worker.getIdx();
        Optional<AttendanceRecord> prev = attendanceRepository.findByWorkerIdxAndWorkDate(wid, rosterDate);
        boolean hadRow = prev.isPresent();
        EmploymentKind preservedEk = prev.map(AttendanceRecord::getEmploymentKind)
                .orElseGet(() -> requireNonNullElse(worker.getEmploymentKind(), EmploymentKind.REGULAR));
        prev.ifPresent(attendanceRepository::delete);
        attendanceRepository.flush();
        attendanceRepository.save(AttendanceRecord.builder()
                .worker(worker)
                .workDate(rosterDate)
                .clockIn(LocalTime.of(6, 0))
                .clockOut(null)
                .manDays(null)
                .attendanceStatus(AttendanceStatus.PRESENT)
                .zoneMain(null)
                .zoneSub(null)
                .assignedTrade(null)
                .employmentKind(preservedEk)
                .build());
        if (!hadRow) {
            acc.attendanceRecords++;
        }
    }

    /** MANAGEMENT_010 게이트 출근 — 추후 WebSocket 동일 페이로드로 대체 가능. */
    @Transactional
    public WorkerDto.GateAttendanceRes recordGateClockIn(WorkerDto.GateClockInReq req) {
        LocalDate date = req.getWorkDate() != null ? req.getWorkDate() : LocalDate.now();
        Worker worker = workerRepository.findById(req.getWorkerIdx())
                .orElseThrow(() -> new BaseException(FAIL));
                // .orElseThrow(() -> new BaseException("WORKER_NOT_FOUND", "작업자를 찾을 수 없습니다."));
        AttendanceRecord old = attendanceRepository.findByWorkerIdxAndWorkDate(req.getWorkerIdx(), date)
                .orElseThrow(() -> new BaseException(FAIL));
                // .orElseThrow(() -> new BaseException("ATT_NOT_FOUND", "해당 일자 명단에 없습니다."));
        LocalTime deadline = attendanceProps.getOfficialStart().plusMinutes(attendanceProps.getLateGraceMinutes());
        AttendanceStatus next = req.getRecognizedAt().isAfter(deadline) ? AttendanceStatus.LATE : AttendanceStatus.PRESENT;

        attendanceRepository.delete(old);
        attendanceRepository.flush();
        AttendanceRecord saved = attendanceRepository.save(AttendanceRecord.builder()
                .worker(worker)
                .workDate(date)
                .clockIn(req.getRecognizedAt())
                .clockOut(old.getClockOut())
                .manDays(old.getManDays())
                .attendanceStatus(next)
                .zoneMain(old.getZoneMain())
                .zoneSub(old.getZoneSub())
                .assignedTrade(old.getAssignedTrade())
                .employmentKind(old.getEmploymentKind())
                .build());
        return toGateRes(saved);
    }

    /** MANAGEMENT_011 게이트 퇴근 — 규정 퇴근 시각 이전이면 {@code EARLY_LEAVE}, 정시 또는 그 이후면 {@code LEAVE}. */
    @Transactional
    public WorkerDto.GateAttendanceRes recordGateClockOut(WorkerDto.GateClockOutReq req) {
        LocalDate date = req.getWorkDate() != null ? req.getWorkDate() : LocalDate.now();
        Worker worker = workerRepository.findById(req.getWorkerIdx())
                .orElseThrow(() -> new BaseException(FAIL));
                // .orElseThrow(() -> new BaseException("WORKER_NOT_FOUND", "작업자를 찾을 수 없습니다."));
        AttendanceRecord old = attendanceRepository.findByWorkerIdxAndWorkDate(req.getWorkerIdx(), date)
                .orElseThrow(() -> new BaseException(FAIL));
                // .orElseThrow(() -> new BaseException("ATT_NOT_FOUND", "해당 일자 명단에 없습니다."));
        if (old.getClockIn() == null) {
            throw new BaseException(FAIL);
            // throw new BaseException("ATT_CLOCK_IN_MISSING", "출근 기록 없이 퇴근할 수 없습니다.");
        }
        AttendanceStatus next = req.getRecognizedAt().isBefore(attendanceProps.getOfficialEnd())
                ? AttendanceStatus.EARLY_LEAVE
                : AttendanceStatus.LEAVE;

        attendanceRepository.delete(old);
        attendanceRepository.flush();
        AttendanceRecord saved = attendanceRepository.save(AttendanceRecord.builder()
                .worker(worker)
                .workDate(date)
                .clockIn(old.getClockIn())
                .clockOut(req.getRecognizedAt())
                .manDays(old.getManDays())
                .attendanceStatus(next)
                .zoneMain(old.getZoneMain())
                .zoneSub(old.getZoneSub())
                .assignedTrade(old.getAssignedTrade())
                .employmentKind(old.getEmploymentKind())
                .build());
        return toGateRes(saved);
    }

    private static WorkerDto.GateAttendanceRes toGateRes(AttendanceRecord a) {
        return WorkerDto.GateAttendanceRes.builder()
                .workerIdx(a.getWorker().getIdx())
                .workDate(a.getWorkDate())
                .clockIn(a.getClockIn())
                .clockOut(a.getClockOut())
                .attendanceStatus(a.getAttendanceStatus())
                .build();
    }

    /**
     * 픽스처에 나온 행만 반영하고 카운터를 올린다.
     * 근태·서류는 자연 키 단위로 삭제 후 재삽입(불변 빌더 엔티티 가정), 이력류는 동일 키면 스킵.
     */
    private void mergeScenarioDetailsFromFixture(Worker worker, WorkerScenarioFixtureRow row, SyncDetailAccumulator acc) {
        Long wid = worker.getIdx();

        if (row.getDocuments() != null) {
            for (WorkerScenarioFixtureRow.DocumentFixtureRow r : row.getDocuments()) {
                documentRepository.findByWorkerIdxAndTitle(wid, r.getTitle()).ifPresent(documentRepository::delete);
                documentRepository.flush();
                documentRepository.save(WorkerDocument.builder()
                        .worker(worker)
                        .title(r.getTitle())
                        .fileUrl(r.getFileUrl())
                        .storedFileName(r.getStoredFileName())
                        .build());
                acc.documents++;
            }
        }
        if (row.getSanctions() != null) {
            for (WorkerScenarioFixtureRow.SanctionFixtureRow r : row.getSanctions()) {
                if (sanctionRepository.existsByWorkerIdxAndOccurredAtAndTypeAndReason(
                        wid,
                        r.getOccurredAt(),
                        requireNonNullElse(r.getType(), ""),
                        requireNonNullElse(r.getReason(), ""))) {
                    continue;
                }
                sanctionRepository.save(WorkerSanction.builder()
                        .worker(worker)
                        .occurredAt(r.getOccurredAt())
                        .type(r.getType())
                        .reason(r.getReason())
                        .action(r.getAction())
                        .active(r.isActive())
                        .build());
                acc.sanctions++;
            }
        }
        if (row.getAccidents() != null) {
            for (WorkerScenarioFixtureRow.AccidentFixtureRow r : row.getAccidents()) {
                String zm = requireNonNullElse(r.getZoneMain(), "").trim();
                String zs = requireNonNullElse(r.getZoneSub(), "").trim();
                if (accidentRepository.existsByWorkerIdxAndOccurredAtAndAccidentTypeAndZoneMainAndZoneSub(
                        wid,
                        r.getOccurredAt(),
                        requireNonNullElse(r.getAccidentType(), ""),
                        zm.isEmpty() ? null : zm,
                        zs.isEmpty() ? null : zs)) {
                    continue;
                }
                accidentRepository.save(SafetyAccident.builder()
                        .worker(worker)
                        .occurredAt(r.getOccurredAt())
                        .accidentType(r.getAccidentType())
                        .zoneMain(zm.isEmpty() ? null : zm)
                        .zoneSub(zs.isEmpty() ? null : zs)
                        .resolution(r.getResolution())
                        .build());
                acc.accidents++;
            }
        }
        if (row.getAttendanceRecords() != null) {
            for (WorkerScenarioFixtureRow.AttendanceFixtureRow r : row.getAttendanceRecords()) {
                String zm = requireNonNullElse(r.getZoneMain(), "").trim();
                String zs = requireNonNullElse(r.getZoneSub(), "").trim();
                String zt = requireNonNullElse(r.getAssignedTrade(), "").trim();
                attendanceRepository.findByWorkerIdxAndWorkDate(wid, r.getWorkDate()).ifPresent(attendanceRepository::delete);
                attendanceRepository.flush();
                attendanceRepository.save(AttendanceRecord.builder()
                        .worker(worker)
                        .workDate(r.getWorkDate())
                        .clockIn(r.getClockIn())
                        .clockOut(r.getClockOut())
                        .manDays(r.getManDays())
                        .attendanceStatus(r.getAttendanceStatus())
                        .zoneMain(zm.isEmpty() ? null : zm)
                        .zoneSub(zs.isEmpty() ? null : zs)
                        .assignedTrade(zt.isEmpty() ? null : zt)
                        .employmentKind(requireNonNullElse(
                                r.getEmploymentKind(),
                                requireNonNullElse(worker.getEmploymentKind(), EmploymentKind.REGULAR)))
                        .build());
                acc.attendanceRecords++;
            }
        }
    }

    private static final class SyncDetailAccumulator {
        int documents;
        int sanctions;
        int accidents;
        int attendanceRecords;
    }

    private static WorkerDto.StateCountRes emptyAttendanceKpi() {
        return WorkerDto.StateCountRes.builder()
                .pending(0)
                .present(0)
                .late(0)
                .leave(0)
                .earlyLeave(0)
                .absent(0)
                .total(0)
                .build();
    }

    /** MANAGEMENT_003 작업자 목록 조회 — 조회일 AttendanceRecord 기준 */
    public WorkerDto.ListRes getList(LocalDate date) {
        LocalDate target = date == null ? LocalDate.now() : date;

        List<AttendanceRecord> records = attendanceRepository.findAllByWorkDate(target);
        Map<Long, AttendanceRecord> attendanceByWorkerIdx = records.stream()
                .collect(Collectors.toMap(a -> a.getWorker().getIdx(), a -> a, (a, b) -> a));

        if (attendanceByWorkerIdx.isEmpty()) {
            WorkerDto.StateCountRes zero = emptyAttendanceKpi();
            return WorkerDto.ListRes.builder()
                    .globalKpi(zero)
                    .listKpi(zero)
                    .rows(List.of())
                    .build();
        }

        List<Worker> workers = workerRepository.findAllById(attendanceByWorkerIdx.keySet());
        workers.sort(Comparator.comparing(Worker::getName, Comparator.nullsLast(String::compareTo)));

        List<WorkerDto.WorkerRes> rows = workers.stream()
                .map(w -> WorkerDto.WorkerRes.from(w, attendanceByWorkerIdx.get(w.getIdx())))
                .collect(Collectors.toList());

        WorkerDto.StateCountRes kpi = aggregateAttendance(rows);
        return WorkerDto.ListRes.builder()
                .globalKpi(kpi)
                .listKpi(kpi)
                .rows(rows)
                .build();
    }

    // MANAGEMENT_002 근무자 검색 — 조회일 ATT 명단 범위 안에서 출근 상태/협력사명/이름 필터 적용
    public WorkerDto.ListRes search(WorkerDto.SearchReq req) {
        LocalDate target = req.getDate() == null ? LocalDate.now() : req.getDate();
        AttendanceStatus statusFilter = req.getAttendanceStatus();

        List<AttendanceRecord> records = attendanceRepository.findAllByWorkDate(target);
        Map<Long, AttendanceRecord> attendanceByWorkerIdx = records.stream()
                .collect(Collectors.toMap(a -> a.getWorker().getIdx(), a -> a, (a, b) -> a));

        if (attendanceByWorkerIdx.isEmpty()) {
            WorkerDto.StateCountRes zero = emptyAttendanceKpi();
            return WorkerDto.ListRes.builder()
                    .globalKpi(zero)
                    .listKpi(zero)
                    .rows(List.of())
                    .build();
        }

        Set<Long> rosterIds = attendanceByWorkerIdx.keySet();
        List<Worker> rosterWorkers = workerRepository.findAllById(rosterIds);
        rosterWorkers.sort(Comparator.comparing(Worker::getName, Comparator.nullsLast(String::compareTo)));

        List<WorkerDto.WorkerRes> allRows = rosterWorkers.stream()
                .map(w -> WorkerDto.WorkerRes.from(w, attendanceByWorkerIdx.get(w.getIdx())))
                .collect(Collectors.toList());
        WorkerDto.StateCountRes globalKpi = aggregateAttendance(allRows);

        List<WorkerDto.WorkerRes> rows = workerRepository
                .search(req.getPartnerCompany(), req.getSearchName())
                .stream()
                .filter(w -> rosterIds.contains(w.getIdx()))
                .map(w -> WorkerDto.WorkerRes.from(w, attendanceByWorkerIdx.get(w.getIdx())))
                .filter(item -> statusFilter == null || item.getAttendanceStatus() == statusFilter)
                .sorted(Comparator.comparing(WorkerDto.WorkerRes::getName, Comparator.nullsLast(String::compareTo)))
                .collect(Collectors.toList());
        WorkerDto.StateCountRes listKpi = aggregateAttendance(rows);

        return WorkerDto.ListRes.builder()
                .globalKpi(globalKpi)
                .listKpi(listKpi)
                .rows(rows)
                .build();
    }

    private WorkerDto.StateCountRes aggregateAttendance(List<WorkerDto.WorkerRes> rows) {
        int pending = 0, present = 0, late = 0, leave = 0, early = 0, absent = 0;
        for (WorkerDto.WorkerRes r : rows) {
            switch (r.getAttendanceStatus()) {
                case PENDING -> pending++;
                case PRESENT -> present++;
                case LATE -> late++;
                case LEAVE -> leave++;
                case EARLY_LEAVE -> early++;
                case ABSENT -> absent++;
            }
        }
        return WorkerDto.StateCountRes.builder()
                .pending(pending)
                .present(present).late(late).leave(leave).earlyLeave(early).absent(absent)
                .total(rows.size())
                .build();
    }
}
